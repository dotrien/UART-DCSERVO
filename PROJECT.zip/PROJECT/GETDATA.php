<?php
    // Send a JSON message to website 
    header ('Content-Type: application/json');
    // Connect to database
    INCLUDE("CONNECT.php");
    $first=$second=$third=$time1=$time2=$time3=0;

    // Read value database DISPLAY table
    $sql2="select *from RETURN_VALUE where STT>(select max(STT) from RETURN_VALUE)-18";
    $res=mysqli_query($conn,$sql2);
    //$row=mysqli_fetch_row($res);
    $data=array();
    foreach($res as $row)
    {
        $data[]=$row;
    }
    mysqli_close($conn);
    echo json_encode($data);
?>

