include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <wiringPi.h>
#include <wiringSerial.h>
#include <mysql.h>
char dataBase;
int fd, RVAL, count;
char VarRec, RDIS;
int VEL, DIS, POS;
char Speed_Set[]="100"; //rad/s
char Position_Set[200]; //degree
MYSQL *conn;
MYSQL_RES *res; // variable used to store DB data
MYSQL_ROW row;
char *server = "192.168.66.51";
char *user = "Trien";
char *password = "12346789t"; 
char *database = "DC_SERVO_MOTOR";

// char chu[10] = "gmp";
// uint8_t tmp;
//char* SoP;
// void Ras_Send( )
// {
// 	if((fd = serialOpen ("/dev/ttyAMA0", 9600)) < 0 )
//         {
// 			fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno));
// 		}
// 		serialPuts(fd, SoP);
// 		serialFlush(fd);
// 		delay(1000);
// }
void Ras_Rec()
{
	char dulieu[10];
	int k=0;
	int enable=0;
	int value_sql;
    if((fd = serialOpen ("/dev/ttyACM0", 115200)) < 0 )
    {
		fprintf (stderr, "Unable to open serial device: %s\n", strerror (errno)) ;
	}else
    {
		do
        {
			VarRec= serialGetchar(fd);
			if(VarRec=='A')
			{
				enable=1;
			}
			else if(VarRec=='B')
			{
				enable=0;
				k=0;
				value_sql=atoi(dulieu);
			}
			else if(enable==1&&VarRec!='A')
			{
				dulieu[k]=VarRec;
				k++;
			}
			printf("%d \n",value_sql);
			//delay(5);
			if(dataBase==0)
			{
				char sql2[200];
				sprintf(sql2,"INSERT INTO RETURN_VALUE (RVEL) values (%d)",value_sql);
				mysql_query(conn,sql2);
			}
			else if(dataBase==1)
			{
				char sql2[200];
				sprintf(sql2,"INSERT INTO RETURN_VALUE (RPOS) value (%d)",value_sql);
				mysql_query(conn,sql2);
			}
			fflush (stdout);

		}
        while(serialDataAvail(fd));

	}
}
int main()
{	

	while(1) 
	{   
	    // Connect to database
		conn = mysql_init(NULL);
		mysql_real_connect(conn,server,user,password,database,0,NULL,0);
		// Create sql command
		char sql[256];
		sprintf(sql,"select *from VALUE");

		// send SQL query
		mysql_query(conn,sql);
		res=mysql_store_result(conn);	
		row=mysql_fetch_row(res);
		

		VEL=atoi(row[0]);
		DIS=atoi(row[1]);
		POS=DIS*360/0.2;
		sprintf(Position_Set,"%d",POS);;
		if(VEL!=0) dataBase=0; // Bien mode
		if(POS!=0) dataBase=1;
		//printf("%d",VEL);		    
	if(dataBase==0)
        {   
			serialPuts(fd,"0");
            delay(1000);
            serialPuts(fd,row[0]);
            
            Ras_Rec();
           
        }                
    else if(dataBase==1)
        {   
			serialPuts(fd,"1");
            delay(1000);
            serialPuts(fd, Position_Set);
           
            Ras_Rec();
            
        }
		    mysql_close(conn);
	}
    serialClose(fd);

	return 0;
}
