#include<stdio.h>
int main()
{
    printf("test ne");
    return 0;
} 