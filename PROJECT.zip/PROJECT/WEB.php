<?php
    // Connect to database
    INCLUDE("CONNECT.php");
    $vel=$pos=0;
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        if($_POST["v"]=="Valueset")
        {
            $vel=0;
        }
        else
        {
            $vel=$_POST["v"];
        }

        if($_POST["p"]=="Valueset")
        {
            $pos=0;
        }
        else
        {
            $pos=$_POST["p"];
        }
        // Update table
        $sql="update VALUE set VEL=$vel, POS=$pos";
        mysqli_query($conn,$sql);
    }
    mysqli_close($conn);

?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title> DC SERVO MOTOR</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <style>
            body
            {
                font:14px sans-serif;
                /*background-image: url('Background1.jpg');*/
                background-color:#aecad3;
            }
            
            .margin-2px {
                margin: 0 3px !important;
                color:#2d0e05;
            }

            .wrapper
            {
                float:left;
                width: 30%;
                padding: 20px;
                margin-top: 50px;
                margin-left: 200px;
                height: 550px;
                color: #192e36 ;
            }
            .box
            {
                margin:auto;
                width: 50%;
                height: 50%;
                
            }
            .chart1
            {
                width: 1500px;
                height: 300px;
            } 
            .chart2
            {
                width: 1500px;
                height: 300px;
            } 
            .row1_1
            {
                display:inline-flex;
            }
            .row
            {
                display:flex;
                flex-direction: row;
            }
            .row2
            {
                width: 200px;
                height: 200px;
            }
            .row1_1_1
            {
                margin-left: 30px;
            }
            .row1_1_2
            {
                margin-left: 50px;
            }
            .bt1
            {
                height: 50px;
                width: 165px;
                font-size: 20px;
            }
            .bt2
            {
                height: 50px;
                width: 165px;
                font-size: 20px;
            }
            h4
            {
                margin-top: 20px;
            }
            .apply
            {
                margin-top: 50px;
                margin-left: 200px;
            }
            .btn
            {
                font-weight: 1000;
                height: 50px;
                width: 100px;
            }
            .p1
            {
                font-size: 20px;
                margin-top:20px;
                margin-left:60px;
            }
            .p2
            {
                font-size: 20px;
                margin-top:20px;
                margin-left:60px;
            }
            img
            {
                height: 110px;
                width: 120px;
                margin-left:40px;
                margin-top: 50px; 
            }
        </style>
    </head>

    <body>
        <h1 style="justify-content: center; display: flex; margin-top: 50px;"> IOT SYSTEM  </h1>
        <h1 style="justify-content: center; display: flex;">CONTROL AND SUPERVISION DC SERVO MOTOR </h1>
 
        <div class="row">
            <div class="wrapper border -2 rounded border-primary" > 
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"  method="POST">
                    <div  class="row1_1"> 
                        <div class="row1_1_1">
                            <h4>SET VELOCITY</h4>
                            <input type="text" value="Valueset" class="bt1" name="v">
                            <h4> SET POSITION</h4>
                            <input type="text" value="Valueset" class="bt2" name="p">
                        </div>
                        <div class="row1_1_2">
                            <h4>VALUE VELOCITY</h4>
                            <p id="vel" class="p1">value</p>
                            <h4 style="margin-top:36px;"> VALUE POSITION</h4>
                            <p id="pos" class="p2">value</p>
                        </div>
                    </div>
                    <div class="apply">
                        <input type="submit" class="btn btn-primary" value="APPLY" >
                    </div>
                    <div class="image1">
                        <img src="Motor.png">
                        <img src="Belt.png">
                        <img src="Bearing.png">
                    </div>
                </form>
            </div>


            <div class="row2">
                <div class="chart1">
                    <div class="wrapper border border-3 rounded border-primary " style="width: 700px; height: 250px;">
                        <canvas id="myChart1"> </canvas>
                    </div>
                </div>
                <div  class="chart2">
                    <div class="wrapper border border-3 rounded border-primary" style="width: 700px; height: 250px;">
                        <canvas id="myChart2"> </canvas>
                    </div>
                </div>
            </div>
        </div>
        <script>
            $(document).ready(function(){
                updateValue();
            });
            setInterval(updateLights,1000);
            function updateLights()
            {
                $.post("GETDATA.php",
                function(data)
                { 
                    var rvel=data[0].RVEL;
                    var rpos=data[0].RPOS;

                    document.getElementById("vel").innerHTML=rvel;
                    document.getElementById("pos").innerHTML=rpos;
                }) 
            }
        </script>
    </body>
</html>