<?php
    // Connect to database
    INCLUDE("CONNECT.php");
    $vel=$pos=0;
    if($_SERVER["REQUEST_METHOD"]=="POST")
    {
        if($_POST["v"]=="Valueset(rad/s)")
        {
            $vel=0;
        }
        else
        {
            $vel=$_POST["v"];
        }

        if($_POST["p"]=="Valueset(cm)")
        {
            $pos=0;
        }
        else
        {
            $pos=$_POST["p"];
        }
        if($_POST["v"]=="Valueset(rad/s)" && $_POST["p"]=="Valueset(cm)" )
        {
            $vel=0;
            $pos=0;
        }
        if($_POST["v"]!="Valueset(rad/s)" && $_POST["p"]!="Valueset(cm)" )
        {
            $vel=0;
            $pos=0;
        }
        // Update table
        $sql="update VALUE set VEL=$vel, POS=$pos";
        mysqli_query($conn,$sql);
    }
    mysqli_close($conn);

?>