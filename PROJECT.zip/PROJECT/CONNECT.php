<?php
    // Ket noi database
    $server="localhost";
    $user="Trien";
    $password="12346789t";
    $dbname="DC_SERVO_MOTOR";

    $conn=mysqli_connect($server, $user, $password, $dbname);
?>  